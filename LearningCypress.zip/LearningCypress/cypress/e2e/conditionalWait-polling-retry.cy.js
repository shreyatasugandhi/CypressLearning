describe('Testing Dynamic Content with Conditional Waits and Retry', () => {

    beforeEach(() => {
      cy.visit('https://the-internet.herokuapp.com/dynamic_loading/2');
    });
  
    it('Built-in Retry = Conditional Wait (Cypress Native)', () => {
      // Click the Start button to initiate loading
      cy.get('#start button').click();
  
      // Cypress will retry until #finish is visible and contains the expected text
      cy.get('#finish', { timeout: 10000 })
        .should('be.visible')
        .and('contain.text', 'Hello World!');
    });
  
    it('Custom polling logic to wait until the content appears', () => {
      cy.get('#start button').click();
  
      // Custom recursive polling logic
      const pollForContent = (retries = 10) => {
        if (retries === 0) {
          throw new Error('Element #finish not found after polling');
        }
  
        cy.get('body').then($body => {
          if ($body.find('#finish:visible').length) {
            cy.get('#finish')
              .should('be.visible')
              .and('contain.text', 'Hello World!');
          } else {
            cy.wait(1000).then(() => {
              pollForContent(retries - 1);
            });
          }
        });
      };
  
      pollForContent();
    });
  
  });
  