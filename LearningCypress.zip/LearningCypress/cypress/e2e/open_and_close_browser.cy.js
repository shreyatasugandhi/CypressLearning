describe('Browser Open and Close Demo', () => {
    before(() => {
      cy.log('Launching test and opening browser');
    });
  
    it('Visits a sample site and performs a check', () => {
      cy.visit('https://www.google.com/');
      cy.title().should('include', 'google');
    });
  
    after(() => {
      cy.log('Test complete. Browser will now close.');
      // Cypress automatically closes the browser after all tests run
    });
  });
  