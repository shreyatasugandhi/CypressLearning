describe('API Mocking Tests - CRUD Operations', () => {
    const apiKey = 'reqres-free-v1';
  
    // 1. Mocking GET (Read) Operation
    it('mocks GET request and verifies response', () => {
      cy.intercept(
        {
          method: 'GET',
          url: 'https://reqres.in/api/users/2',
          headers: {
            'x-api-key': apiKey,
          }
        },
        {
          statusCode: 200,
          body: {
            data: {
              id: 2,
              email: 'mocked.user@reqres.in',
              first_name: 'Mocked',
              last_name: 'User',
              avatar: 'https://reqres.in/img/faces/2-image.jpg'
            }
          }
        }
      ).as('getUser');
  
      cy.visit('src/mock-page.html');  // Ensure path is correct
      cy.get('#getUserBtn').click();  // Trigger the GET request
  
      cy.wait('@getUser', { timeout: 10000 });
  
      cy.window()
        .its('apiResult')
        .should('exist')
        .then((result) => {
          expect(result.data.email).to.eq('mocked.user@reqres.in');
        });
    });
  
    
    // 2. Mocking POST (Create) Operation
    it('mocks POST request to create a new user', () => {
      cy.intercept(
        {
          method: 'POST',
          url: 'https://reqres.in/api/users',
          headers: {
            'x-api-key': apiKey,
          }
        },
        {
          statusCode: 201,
          body: {
            name: 'John Doe',
            job: 'Software Engineer',
            id: 1001
          }
        }
      ).as('createUser');
  
      cy.visit('src/mock-page.html');  // Ensure path is correct
      cy.get('#createUserBtn').click();  // Trigger the POST request
  
      cy.wait('@createUser', { timeout: 10000 });
  
      cy.window()
        .its('apiResult')
        .should('exist')
        .then((result) => {
          expect(result.name).to.eq('John Doe');
          expect(result.job).to.eq('Software Engineer');
          expect(result.id).to.eq(1001);
        });
    });



    // 3. Mocking PUT (Update) Operation
    it('mocks PUT request to update an existing user', () => {
      cy.intercept(
        {
          method: 'PUT',
          url: 'https://reqres.in/api/users/2',
          headers: {
            'x-api-key': apiKey,
          }
        },
        {
          statusCode: 200,
          body: {
            id: 2,
            name: 'Jane Doe',
            job: 'Senior Software Engineer',
            updatedAt: '2025-04-30T09:35:32.123Z'
          }
        }
      ).as('updateUser');
  
      cy.visit('src/mock-page.html');  // Ensure path is correct
      cy.get('#updateUserBtn').click();  // Trigger the PUT request
  
      cy.wait('@updateUser', { timeout: 10000 });
  
      cy.window()
        .its('apiResult')
        .should('exist')
        .then((result) => {
          expect(result.name).to.eq('Jane Doe');
          expect(result.job).to.eq('Senior Software Engineer');
        });
    });
  
    
    // 4. Mocking DELETE (Delete) Operation
    it('mocks DELETE request to delete a user', () => {
      cy.intercept(
        {
          method: 'DELETE',
          url: 'https://reqres.in/api/users/2',
          headers: {
            'x-api-key': apiKey,
          }
        },
        {
          statusCode: 204,
          body: null
        }
      ).as('deleteUser');
  
      cy.visit('src/mock-page.html');  // Ensure path is correct
      cy.get('#deleteUserBtn').click();  // Trigger the DELETE request
  
      cy.wait('@deleteUser', { timeout: 10000 });
  
      cy.window()
        .its('apiResult')
        .should('not.exist')
        .then((result) => {
            expect(result.status).to.eq(204)
        })
    });
  });
  