/// <reference types="cypress" />

describe('Reqres API Testing with API Key', () => {
  const apiKey = 'reqres-free-v1'; // API Key defined locally for this file
  const baseUrl = 'https://reqres.in'; // Base URL for Reqres

  // Helper method to attach headers consistently
  const apiRequest = (options) => {
    return cy.request({
      ...options,
      headers: {
        'x-api-key': apiKey,
        'Content-Type': 'application/json',
        Accept: '*/*',
        ...(options.headers || {}),
      }
    });
  };

  it('GET - Fetch a single user', () => {
    apiRequest({
      method: 'GET',
      url: `${baseUrl}/api/users/2`,
    }).then((response) => {
      expect(response.status).to.eq(200);
      expect(response.body.data).to.have.property('id', 2);
    });
  });

  it('POST - Create a new user', () => {
    apiRequest({
      method: 'POST',
      url: `${baseUrl}/api/users`,
      body: {
        name: 'John Doe',
        job: 'Software Engineer'
      }
    }).then((response) => {
      expect(response.status).to.eq(201);
      expect(response.body).to.have.property('name', 'John Doe');
    });
  });


  it('PUT - Update an existing user', () => {
    apiRequest({
      method: 'PUT',
      url: `${baseUrl}/api/users/2`,
      body: {
        name: 'Jane Doe',
        job: 'Manager'
      }
    }).then((response) => {
      expect(response.status).to.eq(200);
      expect(response.body).to.have.property('name', 'Jane Doe');
    });
  });


  it('PATCH - Partially update an existing user', () => {
    apiRequest({
      method: 'PATCH',
      url: `${baseUrl}/api/users/2`,
      body: {
        job: 'Product Owner'
      }
    }).then((response) => {
      expect(response.status).to.eq(200);
      expect(response.body).to.have.property('job', 'Product Owner');
    });
  });

  it('DELETE - Remove a user', () => {
    apiRequest({
      method: 'DELETE',
      url: `${baseUrl}/api/users/2`
    }).then((response) => {
      expect(response.status).to.eq(204);
    });
  });
});
