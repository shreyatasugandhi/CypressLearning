describe('Cypress Assertion Types Demo', function () {

    beforeEach(() => {
      cy.visit('https://the-internet.herokuapp.com/login')
    })
  
    // 1. Implicit Assertions (should, and)
    it('Implicit assertions - should & and', () => {
      cy.url().should('include', 'login')
        .and('contain', 'internet')
        .and('not.contain', 'error')
  
      cy.get('h2').should('be.visible')
        .and('contain.text', 'Login Page')

    })
  

    // 2. Explicit Assertions using expect
    it('Explicit assertions - expect', () => {
      cy.get('h2').then((header) => {
        expect(header.text()).to.equal('Login Page')
        expect(header).to.have.lengthOf(1)
      })
    })
  
   
    // 3. Equality and Value Assertions
    it('Equality and Value assertions', () => {
      cy.get('#username').type('tomsmith').should('have.value', 'tomsmith')
    })
   
    // 4. Existence and Visibility
    it('Existence and visibility', () => {
      cy.get('#login').should('exist').and('be.visible')
    })
   
    // 5. State assertions (enabled/disabled, checked/unchecked)
    it('State assertions', () => {
      cy.get('#username').should('be.enabled')
      cy.get('#username').should('not.be.disabled')
    })
    
  
    // 6. Length assertions
    it('Length assertions', () => {
      cy.get('form input').should('have.length', 2) 
    })  

    
    // 7. Class and Attribute assertions
    it('Class and attribute assertions', () => {
      cy.get('button.radius')
        .should('have.class', 'radius')
        .and('have.attr', 'type', 'submit') 
    })
  
   
    // 8. Negative assertions
    it('Negative assertions', () => {
      cy.get('#username').should('not.have.value', 'wronguser')
    })


    // 9. Text content assertions
    it('Text content assertions', () => {
      cy.get('h2').should('have.text', 'Login Page')
      cy.get('h2').should('contain.text', 'Login')
    })
  

    // 10. Assertions after login
    it('Post-login assertions', () => {
      cy.get('#username').type('tomsmith')
      cy.get('#password').type('SuperSecretPassword!')
      cy.get('button[type="submit"]').click()
  
      cy.url().should('include', '/secure')
      cy.get('#flash').should('contain.text', 'You logged into a secure area!')
    })
  
    
    // 11. Assertion on list items (length and text match)
    it('List assertions', () => {
      cy.visit('https://the-internet.herokuapp.com/checkboxes')
      cy.get('input[type="checkbox"]').should('have.length', 2)
    })
  
    // 12. Assertion on dynamic elements (waited presence)
    it('Dynamic content assertions', () => {
      cy.visit('https://the-internet.herokuapp.com/dynamic_loading/1')
      cy.contains('Start').click()
      cy.get('#finish', { timeout: 10000 }).should('contain.text', 'Hello World!')
    })
  
  })
  