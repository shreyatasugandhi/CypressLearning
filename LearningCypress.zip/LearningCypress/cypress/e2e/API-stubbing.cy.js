describe('API Stubbing Tests - CRUD Operations', () => {
    const apiKey = 'reqres-free-v1';
  
    // 1. Stubbing GET (Read) Operation
    it('stubs GET request and verifies response', () => {
      cy.intercept(
        {
          method: 'GET',
          url: 'https://reqres.in/api/users/2',
          headers: {
            'x-api-key': apiKey,
          }
        },
        {
          statusCode: 200,
          body: {
            data: {
              id: 2,
              email: 'stubbed.user@reqres.in',
              first_name: 'Stubbed',
              last_name: 'User',
              avatar: 'https://reqres.in/img/faces/2-image.jpg'
            }
          }
        }
      ).as('getUser');
  
      cy.visit('src/stub-page.html');  // Ensure path is correct
      cy.get('#getUserBtn').click();  // Trigger the GET request
  
      cy.wait('@getUser', { timeout: 10000 });
  
      cy.window()
        .its('apiResult')
        .should('exist')
        .then((result) => {
          expect(result.data.email).to.eq('stubbed.user@reqres.in');
        });
    });
  });


  describe('API Stubbing Tests - CRUD Operations', () => {
    const apiKey = 'reqres-free-v1';
  
    beforeEach(() => {
      cy.visit('src/stub-page.html'); // Make sure path to your HTML page is correct
    });
  
    // 1. Stubbing GET (Read) Operation
    it('stubs GET request to fetch a user', () => {
      // Create a stub that returns a predefined response
      const getUserStub = cy.stub().returns(
        Promise.resolve({
          json: () =>
            Promise.resolve({
              data: {
                id: 2,
                email: 'stubbed.user@reqres.in',
                first_name: 'Stubbed',
                last_name: 'User',
                avatar: 'https://reqres.in/img/faces/2-image.jpg'
              }
            })
        })
      );
  
      // Stub the window's fetch function to use the above response
      cy.window().then((win) => {
        cy.stub(win, 'fetch').callsFake(getUserStub);
      });
  
      // Trigger the button click to call the GET request
      cy.get('#getUserBtn').click();
  
      // Assert the stub was called once
      cy.wrap(getUserStub).should('have.been.calledOnce');
  
      // Assert the response data is correct
      cy.window()
        .its('apiResult')
        .should('exist')
        .then((result) => {
          expect(result.data.email).to.eq('stubbed.user@reqres.in');
        });
    });
  

   
    // 2. Stubbing POST (Create) Operation
    it('stubs POST request to create a new user', () => {
      const createUserStub = cy.stub().returns(
        Promise.resolve({
          json: () =>
            Promise.resolve({
              name: 'John Stub',
              job: 'Software Engineer',
              id: 1001
            })
        })
      );
  
      cy.window().then((win) => {
        cy.stub(win, 'fetch').callsFake(createUserStub);
      });
  
      cy.get('#createUserBtn').click();
  
      cy.wrap(createUserStub).should('have.been.calledOnce');
  
      cy.window()
        .its('apiResult')
        .should('exist')
        .then((result) => {
          expect(result.name).to.eq('John Stub');
          expect(result.job).to.eq('Software Engineer');
          expect(result.id).to.eq(1001);
        });
    });

  
    // 3. Stubbing PUT (Update) Operation
    it('stubs PUT request to update a user', () => {
      const updateUserStub = cy.stub().returns(
        Promise.resolve({
          json: () =>
            Promise.resolve({
              name: 'Jane Stub',
              job: 'Senior Software Engineer',
              updatedAt: new Date().toISOString()
            })
        })
      );
  
      cy.window().then((win) => {
        cy.stub(win, 'fetch').callsFake(updateUserStub);
      });
  
      cy.get('#updateUserBtn').click();
  
      cy.wrap(updateUserStub).should('have.been.calledOnce');
  
      cy.window()
        .its('apiResult')
        .should('exist')
        .then((result) => {
          expect(result.name).to.eq('Jane Stub');
          expect(result.job).to.eq('Senior Software Engineer');
        });
    });
  
    
    // 4. Stubbing DELETE (Delete) Operation
    it('stubs DELETE request to delete a user', () => {
        // Create a stub that simulates a successful DELETE request with no body
        const deleteUserStub = cy.stub().returns(
          Promise.resolve({
            json: () => Promise.resolve({}) // Return an empty object for DELETE request response
          })
        );
      
        // Stub the window's fetch function to use the above response
        cy.window().then((win) => {
          cy.stub(win, 'fetch').callsFake(deleteUserStub);
        });
      
        // Trigger the button click to simulate the DELETE request
        cy.get('#deleteUserBtn').click();
      
        // Assert that the stub was called once
        cy.wrap(deleteUserStub).should('have.been.calledOnce');
      
        // Check if apiResult is either null, undefined or an empty object {}
        cy.window()
          .its('apiResult')
          .should('satisfy', (result) => {
            // result should be null, undefined, or an empty object
            return result === null || result === undefined || Object.keys(result).length === 0;
          });
      });
      
      
  });
  
