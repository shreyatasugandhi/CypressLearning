describe('template spec', () => {
  it('passes', () => {
    cy.visit('https://www.google.com/')
    cy.url().should('include', 'google')
  })
})