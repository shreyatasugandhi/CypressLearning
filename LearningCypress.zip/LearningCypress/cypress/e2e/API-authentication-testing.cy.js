describe('Authentication and Login API Testing', () => {
    const baseUrl = 'https://reqres.in/api'; // Using reqres example API
    const apiKey = 'reqres-free-v1'; // your free API key
  
    // Utility function for sending requests with API key
    const apiRequest = (options) => {
      return cy.request({
        ...options,
        headers: {
          'x-api-key': apiKey,
          'Content-Type': 'application/json',
          Accept: '*/*',
          ...options.headers, // allow extra headers if needed
        },
        failOnStatusCode: false // so we can validate 4xx or 5xx responses manually
      });
    };
  
    it('Successful Login', () => {
      apiRequest({
        method: 'POST',
        url: `${baseUrl}/login`,
        body: {
          email: 'eve.holt@reqres.in',
          password: 'cityslicka'
        }
      }).then((response) => {
        expect(response.status).to.eq(200);
        expect(response.body).to.have.property('token');
        cy.log('Token received:', response.body.token);
      });
    });
  
    
    it('Login Failure - Missing Password', () => {
      apiRequest({
        method: 'POST',
        url: `${baseUrl}/login`,
        body: {
          email: 'eve.holt@reqres.in'
          // password intentionally missing
        }
      }).then((response) => {
        expect(response.status).to.eq(400);
        expect(response.body.error).to.eq('Missing password');
        cy.log('Proper error message received for missing password');
      });
    });

  
    it('Login Failure - Invalid User', () => {
      apiRequest({
        method: 'POST',
        url: `${baseUrl}/login`,
        body: {
          email: 'nonexistentuser@reqres.in',
          password: 'wrongpassword'
        }
      }).then((response) => {
        expect(response.status).to.eq(400);
        expect(response.body).to.have.property('error');
        cy.log('Handled invalid login gracefully');
      });
    });


    
    it('Access Protected Resource After Login (Hypothetical)', () => {
      // Ideally you would first log in, get token, then access protected resource
      apiRequest({
        method: 'POST',
        url: `${baseUrl}/login`,
        body: {
          email: 'eve.holt@reqres.in',
          password: 'cityslicka'
        }
      }).then((loginResponse) => {
        expect(loginResponse.status).to.eq(200);
        const token = loginResponse.body.token;
  
        // Now access some protected API (hypothetical)
        apiRequest({
          method: 'GET',
          url: `${baseUrl}/users/2`,
          headers: {
            Authorization: `Bearer ${token}` // attach token
          }
        }).then((userResponse) => {
          expect(userResponse.status).to.eq(200);
          expect(userResponse.body.data).to.have.property('id', 2);
          cy.log('Successfully accessed protected resource with valid token');
        });
      });
    });
  });
  