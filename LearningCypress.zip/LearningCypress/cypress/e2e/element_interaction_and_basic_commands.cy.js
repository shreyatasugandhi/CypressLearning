describe('Basic Commands and Element Interaction Suite on Herokuapp', function () {

    beforeEach(() => {
        cy.visit('https://the-internet.herokuapp.com/')
    })

    it('Typing into input fields', function () {
        cy.contains('Form Authentication').click()
        cy.get('#username').type('tomsmith')
        cy.get('#password').type('SuperSecretPassword!')
    })
  
    it('Clicking buttons', function () {
        cy.contains('Form Authentication').click()
        cy.get('#username').type('tomsmith')
        cy.get('#password').type('SuperSecretPassword!')
        cy.get('button[type="submit"]').click()
    })
   

    it('Validating text content', function () {
        cy.contains('Form Authentication').click()
        cy.get('#username').type('tomsmith')
        cy.get('#password').type('SuperSecretPassword!')
        cy.get('button[type="submit"]').click()
        cy.get('#flash').should('contain.text', 'You logged into a secure area!')
    })


    it('Clearing input fields', function () {
        cy.contains('Form Authentication').click()
        cy.get('#username').type('tomsmith').clear()
        cy.get('#username').should('have.value', '')
    })

    
    it('Check existence and visibility of an element', function () {
        cy.contains('Form Authentication').click()
        cy.get('h2').should('exist').and('be.visible')
    })


    it('Using assertions to check input value', function () {
        cy.contains('Form Authentication').click()
        cy.get('#username').type('cypressUser')
        cy.get('#username').should('have.value', 'cypressUser')
    })

    
    it('Checking and unchecking checkboxes', function () {
        cy.contains('Checkboxes').click()
        cy.get('input[type="checkbox"]').eq(0).check().should('be.checked')
        cy.get('input[type="checkbox"]').eq(1).uncheck().should('not.be.checked')
        cy.wait(2000)
    })

    
    it('Selecting a value from a dropdown', function () {
        cy.contains('Dropdown').click() 
        cy.get('select').select('Option 2').should('have.value', '2')
    })
    

    it('Using contains() for partial text match', function () {
        cy.contains('Elemental Selenium').should('exist')
    })


    
    it('Radio Buttons', function () {
        cy.origin('https://example.cypress.io', () => {
            cy.visit('/commands/actions')

            cy.get('.action-radios [type="radio"]').check('radio2');
            cy.get('.action-radios [type="radio"][value="radio2"]').should('be.checked');
        })
    })

    
    it.only('Links and Navigation', function () {
        cy.contains('A/B Testing').click()
        cy.url().should('include', '/abtest')
    })

    it.only('Text and Headings', function () {
        cy.get('h1').should('contain.text', 'Welcome')
        cy.get('h2').should('exist')
    })

})
