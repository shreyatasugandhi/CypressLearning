describe.only('Testing Dynamic Content and AJAX Calls', () => {

    beforeEach(() => {
      cy.visit('https://the-internet.herokuapp.com/dynamic_loading/2');
    });
  
    it('Waits for dynamic content to load using explicit wait', () => {
      cy.get('button').click();
  
      // Cypress waits up to 10s for #finish to appear and become visible
      cy.get('#finish', { timeout: 10000 })
        .should('be.visible')
        .and('contain.text', 'Hello World!');
    });
  
    it('Handles retry logic for dynamic content without hard waits', () => {
      cy.get('button').click();
  
      // Retry using .should with a function for more control
      cy.get('#finish', { timeout: 10000 }).should(($el) => {
        expect($el).to.be.visible;
        expect($el.text().trim()).to.equal('Hello World!');
      });
    });
  });
  
  
  describe.skip('AJAX Call Interception using cy.intercept()', () => {
    beforeEach(() => {
      cy.intercept('GET', '/api/data', { fixture: 'data.json' }).as('fetchData');
      cy.visit('http://localhost:8080/ajax.html'); // adjust path based on server root
    });
  
    it('should intercept AJAX call and render mocked data', () => {
      cy.get('#load-button').click();
      cy.wait('@fetchData').its('response.statusCode').should('eq', 200);
      cy.get('.data-container').should('contain.text', 'Hello from mocked API!');
      cy.wait(5000)
    });
  });
    