describe('Wait Methods in Cypress - Resilient Version', () => {

    beforeEach(() => {
        // Visit target site
        cy.visit('https://the-internet.herokuapp.com/dynamic_loading/1');
    });

    it('Static wait using cy.wait() - handled', () => {
        cy.get('button').click();

        // Wait for element to appear (not ideal but sometimes necessary)
        cy.wait(10000); // Increased to 10s for slow-render elements

        cy.get('#finish').should('be.visible').and('contain', 'Hello World!');
    });


    it('Wait using built-in timeout retry - preferred way', () => {
        cy.get('button').click();

        // Use built-in retry mechanism with custom timeout
        cy.get('#finish', { timeout: 15000 }).should('be.visible').and('contain.text', 'Hello World!');
    });


    it('Explicit wait using .should()', () => {
        cy.get('button').click();

        // Wait and assert element's text content
        cy.get('#finish', { timeout: 15000 }).should(($el) => {
            expect($el.text().trim()).to.equal('Hello World!');
        });
    });
    

    it('Wait using network intercept - fixed for dynamic loading', () => {
        // Intercept actual call used by dynamic loading button
        cy.intercept('GET', '**/dynamic_loading/1').as('loadPage');

        cy.reload(); // Ensures the intercept applies before click
        cy.wait('@loadPage'); // Wait for page to load

        cy.get('button').click();

        // Now wait for text to appear after async behavior
        cy.get('#finish', { timeout: 15000 }).should('contain.text', 'Hello World!');
    });

});
