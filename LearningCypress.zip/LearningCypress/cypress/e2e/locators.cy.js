/**
 * cy.get(selector, options?).action.action.action
 * 
 * selector --	A CSS selector string (e.g., '#username', '.btn', 'input[name="q"]')
 * options ---	(Optional) Timeout or logging control options
 * action  ---  Action to be perfromed on the element located
 * 
 * OR 
 * 
 * cy.contains(contentText, options?)
 * 
 * used for text based Locator
 * contentText ---	Exact or partial text to search for
 * 
 * CSS Selctors -
 * id = #id 
 * classname = .classname
 * name = [Attribute = value]
 * Attribute = [Attribute = value]
 * tag = tagname 
 * tag + id = tagname#id
 * tag + class = tagname.classname
 * id + class = #id.classname
 * tag + Attribute = tagname[Attribute = value]
 * id + class + tag + Attribute = tagname#id.classname[Attribute=value]
 * 
 */




describe('Locator Techniques on Herokuapp', function () {

  beforeEach(() => {
    cy.visit('https://the-internet.herokuapp.com/')
  })

  it('Locates using Tag Name', function () {
    cy.get('h1').should('contain.text', 'Welcome')
  })

  it('Locates using Class Name', function () {
    cy.get('.heading').should('exist')
  })

  it('Locates using ID', function () {
    cy.get('#content').should('be.visible')
  })

  it('Locates using Tag + Class Combination', function () {
    cy.contains('Checkboxes').click()
    cy.get('div.example').should('exist')
  })


  it('Locates using Link Text (contains)', function () {
    cy.contains('Dropdown').should('exist')
  })

  it('Locates using Partial Link Text (contains)', function () {
    cy.contains('Dynamic').should('exist')
    cy.contains('Dynamic').click()
  })

  it('Locates using Attribute', function () {
    cy.get('[href="/abtest"]').should('exist')
  })

  it('Locates using Partial Attribute Match', function () {
    cy.get('[href*="add_remove"]').should('exist')
  })

  it('Locates using Visible Text', function () {
    cy.contains('Checkboxes').should('exist')
  })

  it('Locates using Index-based Selection', function () {
    cy.get('li').eq(3).should('exist')
  })

  it('Locates using Scoped Find inside a Parent Element', function () {
    cy.get('#content').find('a').should('have.length.greaterThan', 10)
  })
})



describe.skip('Form interaction with scoped cy.get().contains()', function () {

  beforeEach(() => {
    cy.visit('https://example.cypress.io/commands/actions')
  })

  it('Finds and clicks the Submit button inside a form', function () {
    cy.get('form[action="/login"]').within(() => {
      cy.get('input[name="email"]').type('test@example.com')
      cy.get('input[name="password"]').type('password123')
      cy.contains('Submit').click()
    })

    // Assertion just to validate no crash; real test would check result
    cy.get('form[action="/login"]').should('exist')
  })

})



describe('Unified Cypress Test Suite on example.cypress.io', () => {

  beforeEach(() => {
    cy.visit('https://example.cypress.io/commands/actions')
  })

  it('Types into an input field and verifies the value', () => {
    cy.get('.action-email')
      .type('user@example.com')
      .should('have.value', 'user@example.com')
  })

  it('Clicks a button and verifies text change or class', () => {
    cy.get('.action-btn')
      .click()
      .should('have.class', 'btn')
  })

 
  it('Finds a button using contains and clicks it', () => {
    cy.contains('Submit').click({ multiple: true, force: true }) // fallback in case more buttons exist
  })

  it('Checks and asserts checkbox state', () => {
    cy.get('.action-checkboxes [type="checkbox"]')
      .eq(0)
      .check()
      .should('be.checked')
  })

  it('Verifies element visibility and class presence', () => {
    cy.get('.action-btn')
      .should('be.visible')
      .and('have.class', 'btn')
  })

})


describe.only('Form Submission Test', () => {
  beforeEach(() => {
    cy.visit('src/form.html');
  });

  it('Finds and clicks the Submit button inside the form container', () => {
    cy.get('.form-container')
      .contains('Submit')
      .click();

  });
});
