// cypress/e2e/authentication-tests-using-postman.cy.js

describe('Authentication Techniques using Postman APIs', () => {
  
    const tests = [
      {
        name: 'Basic Authentication',
        method: 'GET',
        url: 'https://postman-echo.com/basic-auth',
        auth: { username: 'postman', password: 'password' },
        assertions: (response) => {
          expect(response.status).to.eq(200);
          expect(response.body.authenticated).to.be.true;
        }
      },
      {
        name: 'Bearer Token Authentication (Simulated)',
        method: 'GET',
        url: 'https://postman-echo.com/headers',
        headers: { Authorization: 'Bearer my_dummy_token_123' },
        assertions: (response) => {
          expect(response.status).to.eq(200);
          expect(response.body.headers).to.have.property('authorization', 'Bearer my_dummy_token_123');
        }
      },
      {
        name: 'API Key Authentication',
        method: 'GET',
        url: 'https://postman-echo.com/get?apikey=my_fake_api_key_456',
        assertions: (response) => {
          expect(response.status).to.eq(200);
          expect(response.body.args.apikey).to.eq('my_fake_api_key_456');
        }
      },
      {
        name: 'Simple Form Login Authentication (Simulated)',
        method: 'POST',
        url: 'https://postman-echo.com/post',
        form: true,
        body: { username: 'postman_user', password: 'secure_password' },
        assertions: (response) => {
          expect(response.status).to.eq(200);
          expect(response.body.form).to.have.property('username', 'postman_user');
        }
      },
      {
        name: 'Session Cookie Based Authentication (Simulated)',
        method: 'GET',
        url: 'https://postman-echo.com/cookies',
        setup: () => cy.setCookie('session_id', 'abc123sessioncookie'),
        headers: { Cookie: 'session_id=abc123sessioncookie' },
        assertions: (response) => {
          expect(response.status).to.eq(200);
          expect(response.body.cookies).to.have.property('session_id', 'abc123sessioncookie');
        }
      }
    ];
  
    tests.forEach(({ name, method, url, auth, headers, form, body, setup, assertions }) => {
      context(name, () => {
        it(`should authenticate using ${name}`, () => {
          if (setup) setup(); // Run any setup actions before the request (e.g., setting cookies)
  
          cy.request({
            method,
            url,
            auth,
            headers,
            form,
            body
          }).then(assertions);
        });
      });
    });
  
  });
  