describe('Data-Driven Testing with JSONPlaceholder API', () => {
    // "before" hook to load fixture data
    before(() => {
      cy.fixture('usersData.json').as('users');
    });
  
    it('Should fetch posts for each user and validate response', function () {
      // Loop through each user in the fixture
      this.users.forEach(user => {
        cy.log(`Testing login for: ${user.username}`); // Log iteration
  
        // Perform API request
        cy.request({
          method: 'GET',
          url: `https://jsonplaceholder.typicode.com/posts?userId=${user.id}`, // Modify API URL if needed
        }).then((response) => {
          // Check response status and validate against expected output
          expect(response.status).to.eq(200);
          expect(response.body).to.be.an('array');
          expect(response.body[0]).to.have.property('userId', user.id);
          cy.wait(5000)  
          // Log success for each iteration
          cy.log(`Posts fetched for user: ${user.username}`);
        });
      });
    });
  });
  