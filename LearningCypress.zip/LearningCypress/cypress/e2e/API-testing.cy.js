describe('API Testing with Cypress', () => {

    const baseUrl = 'https://jsonplaceholder.typicode.com'; //Public API, no auth needed
  
    it('GET request - Fetch a list of posts', () => {
      cy.request(`${baseUrl}/posts`).then((response) => {
        expect(response.status).to.eq(200);
        expect(response.body).to.be.an('array');
        expect(response.body.length).to.be.greaterThan(0);
        expect(response.headers['content-type']).to.include('application/json');
      });
    });

    
    it('GET request - Validate a specific post', () => {
      cy.request(`${baseUrl}/posts/1`).then((response) => {
        expect(response.status).to.eq(200);
        expect(response.body).to.have.property('id', 1);
        expect(response.body).to.have.property('userId');
        expect(response.body).to.have.property('title');
      });
    });

    
  
    it('POST request - Create a new post', () => {
      cy.request({
        method: 'POST',
        url: `${baseUrl}/posts`,
        body: {
          title: 'Automated Cypress Post',
          body: 'This is an example created during API automation.',
          userId: 1
        },
        headers: {
          'Content-type': 'application/json; charset=UTF-8',
        },
      }).then((response) => {
        expect(response.status).to.eq(201); // Created
        expect(response.body).to.have.property('id');
        expect(response.body.title).to.eq('Automated Cypress Post');
      });
    });
  



    
    it('PUT request - Update an existing post', () => {
      cy.request({
        method: 'PUT',
        url: `${baseUrl}/posts/1`,
        body: {
          id: 1,
          title: 'Updated Title via Cypress',
          body: 'Updated body content.',
          userId: 1
        },
        headers: {
          'Content-type': 'application/json; charset=UTF-8',
        },
      }).then((response) => {
        expect(response.status).to.eq(200);
        expect(response.body.title).to.eq('Updated Title via Cypress');
      });
    });
  


    
    it('DELETE request - Delete a post', () => {
      cy.request({
        method: 'DELETE',
        url: `${baseUrl}/posts/1`,
      }).then((response) => {
        expect(response.status).to.eq(200); // JSONPlaceholder returns 200 on DELETE
      });
    });
  

    
  });
  