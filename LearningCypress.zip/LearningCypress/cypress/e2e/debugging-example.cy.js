describe('Debugging Techniques Demo', () => {

    beforeEach(() => {
      cy.visit('https://the-internet.herokuapp.com/login')
    })
  
    it('Using console.log for debugging', () => {
      cy.get('#username').type('tomsmith').then(($el) => {
        cy.wait(2000)
        console.log('Entered username:', $el.val())
        cy.wait(5000)
      })
  
      cy.get('#password').type('SuperSecretPassword!').then(($el) => {
        console.log('Entered password:', $el.val())
        cy.wait(50000)
      })
    })
  
    
    it('Using cy.debug() to inspect elements', () => {
      cy.get('form').debug() // opens in DevTools console
      cy.get('button[type="submit"]').debug().click()
      cy.wait(5000)
    })
  



    it('Using cy.pause() to halt execution', () => {
      cy.pause() // test will stop here until you manually resume
      cy.get('#username').type('tomsmith')
      cy.get('#password').type('SuperSecretPassword!')
      cy.get('button[type="submit"]').click()
      
    })
  

    it('Using debugger keyword in a .then()', () => {
      cy.get('#username').type('tomsmith').then(() => {
        debugger // triggers DevTools debugger if open
      })
      cy.get('#password').type('SuperSecretPassword!')
      cy.get('button[type="submit"]').click()
    })
  })
  