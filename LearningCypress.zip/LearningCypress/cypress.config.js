const { defineConfig } = require("cypress");

module.exports = defineConfig({
  projectId: 'bk7d1p',
  e2e: {
    setupNodeEvents(on, config) {
      // implement node event listeners here
      
    },
  },
});
