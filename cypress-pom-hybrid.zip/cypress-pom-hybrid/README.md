# Cypress OPM Hybrid Framework
This is a scalable Page Object Model hybrid framework using Cypress for web (SauceDemo) and API (GoRest) testing.