class ProfilePage {
  // Menu button
  static getMenuButton() {
    return cy.get('#react-burger-menu-btn');
  }

  // About link in the sidebar
  static getAboutLink() {
    return cy.get('#about_sidebar_link');
  }

  // Open the sidebar menu
  static openMenu() {
    this.getMenuButton().should('be.visible').click();
  }

  // Click on the About link
  static clickAbout() {
    this.getAboutLink().should('be.visible').click();
  }
}

export default ProfilePage;
