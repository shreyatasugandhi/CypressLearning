class ProfilePage {
  viewProfile() {
    cy.get('.bm-item').contains('Profile').click();
  }

  getProfileDetails() {
    return cy.get('.profile-info');
  }
}

export default new ProfilePage();