const loginPageElements = {
  usernameInput: '#user-name',
  passwordInput: '#password',
  loginButton: '#login-button',
  errorMessage: '[data-test="error"]'
};

class LoginPage {
  visit() {
    cy.visit(Cypress.config('baseUrl')); // pulled from cypress.config.js
  }

    login(username, password) {
    cy.get(loginPageElements.usernameInput).type(username);
    cy.get(loginPageElements.passwordInput).type(password);
    cy.get(loginPageElements.loginButton).click();
  }

  getErrorMessage() {
    return cy.get(loginPageElements.errorMessage);
  }
}

export default new LoginPage();