const SELECTORS = {
  pageTitle: '.title',
  inventoryItem: '.inventory_item',
  cartBadge: '.shopping_cart_badge',
};

class DashboardPage {
  verifyLanding() {
    const baseUrl = Cypress.config('baseUrl');
    cy.url().should('eq', `${baseUrl}/inventory.html`);
    cy.get(SELECTORS.pageTitle).should('contain.text', 'Products');
  }

  getAllProducts() {
    return cy.get(SELECTORS.inventoryItem);
  }

  addProductToCart(productName) {
    cy.get(SELECTORS.inventoryItem)
      .contains(productName)
      .parents(SELECTORS.inventoryItem)
      .find('button')
      .click();
  }

  getCartBadge() {
    return cy.get(SELECTORS.cartBadge);
  }
}

export default new DashboardPage();
