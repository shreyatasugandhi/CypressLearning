class DashboardPage {
  static getProducts() {
    return cy.get('.inventory_item');
  }

  static addProductToCart(productName) {
    cy.get('.inventory_item')
      .contains(productName)
      .parents('.inventory_item')
      .find('button')
      .click();
  }

  static getCartBadge() {
    return cy.get('.shopping_cart_badge');
  }
}

export default DashboardPage;
