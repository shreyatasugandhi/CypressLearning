// Web login command for saucedemo
Cypress.Commands.add('login', (username, password) => {
  cy.visit('/');
  cy.get('#user-name').type(username);
  cy.get('#password').type(password);
  cy.get('#login-button').click();
});

// API request wrapper for GoRest
Cypress.Commands.add('apiRequest', (options) => {
  const apiKey = Cypress.env('gorestToken');

  const updatedOptions = {
    ...options,
    headers: {
      ...(options.headers || {}),
      Authorization: `Bearer ${apiKey}`,
      'Content-Type': 'application/json',
      Accept: 'application/json'
    }
  };

  return cy.request(updatedOptions);
});
