// cypress/support/utils.js
import { faker } from '@faker-js/faker';

export const generateRandomEmail = () => {
  const randomString = Math.random().toString(36).substring(2, 15);
  return `${randomString}@example.com`;
};

export const generateRandomUser = () => {
  return {
    name: faker.person.fullName(),
    email: generateRandomEmail(),
    gender: faker.helpers.arrayElement(['male', 'female']),
    status: 'active',
  };
};
