
// Import custom commands
import './commands';

// Global hooks
beforeEach(() => {
  cy.clearCookies();
  cy.clearLocalStorage();
});

afterEach(() => {
  cy.log('Test completed');
});
