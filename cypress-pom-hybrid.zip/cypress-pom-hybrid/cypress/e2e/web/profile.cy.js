import LoginPage from '../../pages/LoginPage';
import ProfilePage from '../../pages/ProfilePage';
import DashboardPage from '../../pages/DashboardPage';
import webTestData from '../../fixtures/webTestData.json';

describe('Profile Page Tests', () => {
  beforeEach(() => {
    cy.visit('/');
    LoginPage.login(webTestData.username, webTestData.password);
    DashboardPage.verifyLanding();
  });

  it('should verify the About link redirects to the correct URL', () => {
    ProfilePage.openMenu();
    ProfilePage.getAboutLink()
      .should('have.attr', 'href')
      .and('include', 'saucelabs.com');
  });

  
});
