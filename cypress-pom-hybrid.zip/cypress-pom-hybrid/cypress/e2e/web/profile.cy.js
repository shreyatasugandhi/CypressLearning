import DashboardPage from '../../pages/DashboardPage';

describe('Profile Page - Simulated via Reset App State', () => {
  beforeEach(() => {
    cy.visit('https://www.saucedemo.com');
    cy.login('standard_user', 'secret_sauce');
    DashboardPage.addProductToCart('Sauce Labs Backpack');
  });

  it('should reset app state via sidebar', () => {
    cy.get('#react-burger-menu-btn').click();
    cy.get('#reset_sidebar_link').click();
    DashboardPage.getCartBadge().should('not.exist');
  });
});
