import LoginPage from '../../pages/LoginPage';
import DashboardPage from '../../pages/DashboardPage';

describe('Dashboard Page Tests', () => {
  let credentials;

  before(() => {
    cy.fixture('webTestData').then((data) => {
      credentials = data;
    });
  });

  beforeEach(() => {
    LoginPage.visit(); // Uses baseUrl from cypress.config.js
    LoginPage.login(credentials.username, credentials.password);
    DashboardPage.verifyLanding(); // Ensure user is on dashboard
  });

  it('should display a list of products on the dashboard', () => {
    DashboardPage.getAllProducts().should('have.length.at.least', 1);
  });

  it('should add a product to the cart and display badge', () => {
    const productToAdd = 'Sauce Labs Backpack';
    DashboardPage.addProductToCart(productToAdd);
    DashboardPage.getCartBadge().should('contain.text', '1');
  });
});
