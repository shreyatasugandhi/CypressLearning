import DashboardPage from '../../pages/DashboardPage';

describe('Dashboard Page', () => {
  beforeEach(() => {
    cy.visit('https://www.saucedemo.com');
    cy.login('standard_user', 'secret_sauce');
  });

  it('should navigate to product page', () => {
    DashboardPage.getProducts().should('exist');
  });

  it('should add product to cart', () => {
    DashboardPage.addProductToCart('Sauce Labs Backpack');
    DashboardPage.getCartBadge().should('contain', '1');
  });
});
