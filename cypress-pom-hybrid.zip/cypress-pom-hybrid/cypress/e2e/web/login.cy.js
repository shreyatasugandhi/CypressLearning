import LoginPage from '../../pages/LoginPage';

describe('Login test cases', () => {
  beforeEach(() => {
    cy.visit('https://www.saucedemo.com');
  });

  it('should login with valid credentials', () => {
    LoginPage.login('standard_user', 'secret_sauce');
    LoginPage.getErrorMessage().should('not.exist');
  });

  it('should show error with invalid credentials', () => {
    LoginPage.login('invalid_user', 'invalid_pass');
    LoginPage.getErrorMessage().should('be.visible');
  });
});