import LoginPage from '../../pages/LoginPage';
import DashboardPage from '../../pages/DashboardPage';
import testData from '../../fixtures/webTestData.json';

describe('Login test cases', () => {
  beforeEach(() => {
    LoginPage.visit();
  });

  it('should login with valid credentials', () => {
    LoginPage.login(testData.username, testData.password);
    LoginPage.getErrorMessage().should('not.exist');
    DashboardPage.verifyLanding();
  });

  it('should show error with invalid credentials', () => {
    LoginPage.login(testData.invalidusername, testData.invalidpassword);
    LoginPage.getErrorMessage().should('be.visible');
  });
});