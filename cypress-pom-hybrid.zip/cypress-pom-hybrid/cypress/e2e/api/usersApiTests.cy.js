import { generateRandomUser, generateRandomEmail } from '../../support/utils';

describe('GoRest User CRUD API Tests using Custom Command', () => {
  const baseUrl = Cypress.env('gorestBaseUrl');
  let userId;
  let userPayload;

  before(() => {
    userPayload = generateRandomUser();
  });

  it('should create a new user and store the user ID', () => {
    cy.apiRequest({
      method: 'POST',
      url: baseUrl,
      body: userPayload
    }).then((response) => {
      expect(response.status).to.eq(201);
      expect(response.body).to.have.property('id');
      expect(response.body).to.include(userPayload);

      userId = response.body.id;
    });
  });

  it('should fetch the created user using the stored ID', () => {
    cy.apiRequest({
      method: 'GET',
      url: `${baseUrl}/${userId}`
    }).then((response) => {
      expect(response.status).to.eq(200);
      expect(response.body).to.have.property('id', userId);
    });
  });

  it('should update the user details using the stored ID', () => {
    const updatedData = {
      name: `Updated ${userPayload.name}`,
      email: generateRandomEmail(),
      status: 'inactive'
    };

    cy.apiRequest({
      method: 'PUT',
      url: `${baseUrl}/${userId}`,
      body: updatedData
    }).then((response) => {
      expect(response.status).to.eq(200);
      expect(response.body).to.include({ id: userId, ...updatedData });
    });
  });

  it('should delete the user using the stored ID', () => {
    cy.apiRequest({
      method: 'DELETE',
      url: `${baseUrl}/${userId}`
    }).then((response) => {
      expect(response.status).to.eq(204);
    });
  });

  it('should return 404 for deleted user ID', () => {
    cy.apiRequest({
      method: 'GET',
      url: `${baseUrl}/${userId}`,
      failOnStatusCode: false
    }).then((response) => {
      expect(response.status).to.eq(404);
      expect(response.body).to.have.property('message', 'Resource not found');
    });
  });
});
