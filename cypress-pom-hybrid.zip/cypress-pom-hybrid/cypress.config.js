const { defineConfig } = require('cypress');

module.exports = defineConfig({
  projectId: '<bk7d1p>',
  e2e: {
    baseUrl: 'https://www.saucedemo.com',
    specPattern: 'cypress/e2e/**/*.cy.js',
    supportFile: 'cypress/support/e2e.js',
    env: {
      gorestToken: '577666251029173162313036de9d315c4aceb5c951f444f75938f7f209c53718',
      gorestBaseUrl: 'https://gorest.co.in/public/v2/users'
    }
  },
  reporter: 'spec'
});
